#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <intrin.h>
#include <windows.h>
#include <wincrypt.h>
#include <ctime> // Ավելացված է ժամանակի աշխատանքի համար

#pragma comment(lib, "advapi32.lib")

using namespace std;

// =======================
// Hardware ID Class
// =======================
class HardwareID {
public:
    static string GetCpuId() {
        int cpuInfo[4] = { -1 };
        // Կանչում ենք Assembly մակարդակի CPUID հրահանգը
        __cpuid(cpuInfo, 1);

        stringstream ss;
        ss << hex << uppercase << setfill('0')
            << setw(8) << cpuInfo[3]
            << setw(8) << cpuInfo[0];

        return ss.str(); // Վերադարձնում է պրոցեսորի եզակի Machine Code-ը
    }
};

// =======================
// License Key Generator (SHA-256)
// =======================
class LicenseKey {
private:
    static const string Salt;

public:
    static string GenerateKey(const string& hardwareId) {
        // Hardware ID-ին գումարում ենք գաղտնի բառ (Salt)՝ հեշն ավելի ապահով դարձնելու համար
        string rawData = hardwareId + Salt;

        HCRYPTPROV hProv = 0;
        HCRYPTHASH hHash = 0;
        string resultHash = "";

        // CryptoAPI-ի կիրառում
        if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
            if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {

                CryptHashData(hHash,
                    reinterpret_cast<const BYTE*>(rawData.c_str()),
                    rawData.length(), 0);

                DWORD hashLen = 0;
                DWORD hashLenSize = sizeof(DWORD);
                CryptGetHashParam(hHash, HP_HASHSIZE,
                    reinterpret_cast<BYTE*>(&hashLen),
                    &hashLenSize, 0);

                if (hashLen > 0) {
                    BYTE* hashBytes = new BYTE[hashLen];

                    if (CryptGetHashParam(hHash, HP_HASHVAL,
                        hashBytes, &hashLen, 0)) {

                        stringstream ss;
                        for (DWORD i = 0; i < hashLen; i++) {
                            ss << hex << uppercase
                                << setw(2) << setfill('0')
                                << (int)hashBytes[i];
                        }

                        // Վերցնում ենք առաջին 20 նիշը որպես բանալի (ուղղված է վրիպակը)
                        resultHash = ss.str().substr(0, 20);
                    }
                    delete[] hashBytes;
                }
                CryptDestroyHash(hHash);
            }
            CryptReleaseContext(hProv, 0);
        }
        return resultHash;
    }
};

const string LicenseKey::Salt = "MySecretLabSalt_CPlusPlus_2024";

// =======================
// License Manager (Node-locked & Trial Period)
// =======================
class LicenseManager {
private:
    static const string LicenseFile;
    static const int TrialDays = 30; // 30 օր փորձաշրջան

public:
    // Ակտիվացման սիմուլյացիա. Պահպանում է բանալին և ակտիվացման ժամանակը
    static void SaveLicense(const string& key) {
        ofstream outFile(LicenseFile);
        if (outFile.is_open()) {
            time_t now = time(0); // Ստանում ենք ընթացիկ ժամանակը (վայրկյաններով)
            outFile << key << endl;
            outFile << now << endl; // Պահպանում ենք ակտիվացման պահի ժամանակը
            outFile.close();
            cout << "[+] License and activation date saved successfully.\n";
        }
    }

    // Լիցենզիայի վալիդացիա՝ Ապարատային + Ժամանակային ստուգում
    static bool ValidateLicense() {
        ifstream inFile(LicenseFile);

        if (!inFile.is_open()) {
            cout << "[-] License file not found. Activation required.\n";
            return false;
        }

        string savedKey;
        string savedTimeStr;
        getline(inFile, savedKey);
        getline(inFile, savedTimeStr); // Կարդում ենք ժամանակը
        inFile.close();

        // 1. Ստուգում ենք Ապարատային համապատասխանությունը (Hardware ID)
        string currentHardwareId = HardwareID::GetCpuId();
        string expectedKey = LicenseKey::GenerateKey(currentHardwareId);

        if (savedKey != expectedKey) {
            cout << "[-] INVALID license (Hardware mismatch! This key belongs to another PC).\n";
            return false;
        }

        // 2. Ստուգում ենք Ժամանակը (Trial Period)
        if (!savedTimeStr.empty()) {
            time_t activationTime = stoll(savedTimeStr); // Տեքստը վերածում ենք թվի
            time_t currentTime = time(0);
            
            // Հակակեղծման ստուգում (Anti-tampering). Արդյոք օգտատերը միտումնավոր հետ է տվել համակարգչի ժամը
            if (currentTime < activationTime) {
                cout << "[-] SYSTEM TIME ALTERATION DETECTED! License blocked.\n";
                return false; 
            }

            // Հաշվում ենք անցած օրերը
            double secondsPassed = difftime(currentTime, activationTime);
            double daysPassed = secondsPassed / (60 * 60 * 24);

            if (daysPassed > TrialDays) {
                cout << "[-] TRIAL EXPIRED! " << fixed << setprecision(1) << daysPassed 
                     << " days passed (Max: " << TrialDays << ").\n";
                return false;
            }

            cout << "[+] License is VALID. " << (TrialDays - (int)daysPassed) << " trial days remaining.\n";
            return true;
        }

        return false;
    }
};

const string LicenseManager::LicenseFile = "license.key";

// =======================
// MAIN FUNCTION
// =======================
int main() {
    cout << "=============================================\n";
    cout << " Software Security - Hardware License System\n";
    cout << "=============================================\n\n";

    // 1. Ստանում ենք ընթացիկ համակարգչի Hardware ID-ն
    string hwId = HardwareID::GetCpuId();
    cout << "Hardware ID: " << hwId << endl;

    // 2. Գեներացնում ենք եզակի լիցենզիայի բանալի տվյալ սարքի համար
    string generatedKey = LicenseKey::GenerateKey(hwId);
    cout << "Generated License Key: " << generatedKey << endl;

    cout << "\n---------------------------------------------\n";

    // 3. Սիմուլյացնում ենք ակտիվացումը (գրանցում ֆայլում): 
    // Նշում. Իրական կյանքում այս ֆունկցիան աշխատում է միայն մեկ անգամ՝ ակտիվացնելիս:
    LicenseManager::SaveLicense(generatedKey);

    // 4. Վավերացնում ենք լիցենզիան ծրագիրը բացելու համար
    cout << "\nValidating license...\n";

    if (LicenseManager::ValidateLicense()) {
        cout << "\n[ SUCCESS ] Access granted. Program started successfully.\n";
    }
    else {
        cout << "\n[ ERROR ] Access denied. Program blocked.\n";
    }

    cout << "\n";
    system("pause");
    return 0;
}